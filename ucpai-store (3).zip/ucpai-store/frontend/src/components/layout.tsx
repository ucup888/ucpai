import { useState, useEffect, ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useGetSettings, useGetPromo, useGetMe } from "@workspace/api-client-react";
import { useAdminSession } from "@/hooks/use-admin-session";
import { Button } from "@/components/ui/button";
import { Moon, Sun, ShoppingBag, Menu, X, Info } from "lucide-react";
import { useTheme } from "next-themes";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface LayoutProps {
  children: ReactNode;
}

export function StoreLayout({ children }: LayoutProps) {
  const { data: settings } = useGetSettings();
  const { data: promo } = useGetPromo();
  const [, setLocation] = useLocation();
  const [tapCount, setTapCount] = useState(0);
  const [showPromo, setShowPromo] = useState(true);
  const { theme, setTheme } = useTheme();

  useEffect(() => {
    if (tapCount > 0) {
      const timer = setTimeout(() => setTapCount(0), 3000);
      if (tapCount >= 10) {
        setLocation("/hidden-core-layer");
        setTapCount(0);
      }
      return () => clearTimeout(timer);
    }
  }, [tapCount, setLocation]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {promo?.enabled && showPromo && promo.text && (
        <div className="bg-secondary text-secondary-foreground px-4 py-2 text-sm flex items-center justify-between">
          <p className="font-medium text-center flex-1">{promo.text}</p>
          <button onClick={() => setShowPromo(false)} className="text-secondary-foreground/80 hover:text-secondary-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
      
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2" onClick={() => setTapCount(c => c + 1)}>
            {settings?.logo ? (
              <img src={settings.logo} alt="Logo" className="h-8 w-8 rounded-md object-cover" />
            ) : (
              <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center text-primary-foreground font-bold">
                U
              </div>
            )}
            <span className="font-bold text-xl tracking-tight text-primary select-none cursor-pointer">
              {settings?.siteName || "UCPAI Store"}
            </span>
          </div>

          <div className="flex items-center gap-4">
            <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
              <Link href="/" className="hover:text-primary transition-colors">Store</Link>
              <Link href="/about" className="hover:text-primary transition-colors">About & FAQ</Link>
            </nav>

            <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </Button>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <nav className="flex flex-col gap-4 mt-8">
                  <Link href="/" className="text-lg font-medium hover:text-primary flex items-center gap-2">
                    <ShoppingBag className="h-5 w-5" /> Store
                  </Link>
                  <Link href="/about" className="text-lg font-medium hover:text-primary flex items-center gap-2">
                    <Info className="h-5 w-5" /> About & FAQ
                  </Link>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6 md:py-8">
        {children}
      </main>

      <footer className="border-t bg-card py-8 md:py-12 mt-auto">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p className="font-medium">{settings?.siteName || "UCPAI Store"} &copy; {new Date().getFullYear()}</p>
          <p className="text-sm mt-2">Your trusted digital marketplace.</p>
        </div>
      </footer>
    </div>
  );
}

export function AdminLayout({ children }: LayoutProps) {
  useAdminSession();
  const [, setLocation] = useLocation();
  const { data: session } = useGetMe();
  const logout = useLogout();
  const { theme, setTheme } = useTheme();
  
  if (!session?.authenticated) {
    return null; // Will be redirected by useAdminSession or protected route logic
  }

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => setLocation("/")
    });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      <aside className="w-full md:w-64 border-r bg-card md:min-h-screen flex flex-col">
        <div className="p-4 md:p-6 border-b">
          <h2 className="font-bold text-xl text-primary">Admin Control</h2>
        </div>
        <nav className="flex-1 flex flex-col gap-1 p-4 overflow-y-auto">
          <Link href="/admin" className="px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground font-medium">Dashboard</Link>
          <Link href="/admin/products" className="px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground font-medium">Products</Link>
          <Link href="/admin/categories" className="px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground font-medium">Categories</Link>
          <Link href="/admin/transactions" className="px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground font-medium">Transactions</Link>
          
          <div className="my-2 border-t" />
          <h3 className="px-3 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Site Config</h3>
          <Link href="/admin/settings" className="px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground text-sm">General Settings</Link>
          <Link href="/admin/payment" className="px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground text-sm">Payment Config</Link>
          <Link href="/admin/contact" className="px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground text-sm">Contact Details</Link>
          <Link href="/admin/promo" className="px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground text-sm">Promo Banner</Link>
          <Link href="/admin/faq" className="px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground text-sm">FAQ Manager</Link>
          <Link href="/admin/about" className="px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground text-sm">About Page</Link>
          <Link href="/admin/theme" className="px-3 py-2 rounded-md hover:bg-accent hover:text-accent-foreground text-sm">Theme Toggle</Link>
        </nav>
        <div className="p-4 border-t flex flex-col gap-2">
          <Button variant="outline" className="w-full justify-start" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
            {theme === "dark" ? <Sun className="mr-2 w-4 h-4" /> : <Moon className="mr-2 w-4 h-4" />}
            Toggle Theme
          </Button>
          <Button variant="destructive" className="w-full justify-start" onClick={handleLogout}>
            Logout
          </Button>
        </div>
      </aside>
      <main className="flex-1 p-4 md:p-8 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}
