import { useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useLogout, useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const INACTIVITY_TIMEOUT = 15 * 60 * 1000; // 15 minutes

export function useAdminSession() {
  const [, setLocation] = useLocation();
  const logout = useLogout();
  const queryClient = useQueryClient();
  const { data: session } = useGetMe();
  const lastActivityRef = useRef(Date.now());

  useEffect(() => {
    if (!session?.authenticated) return;

    const updateActivity = () => {
      lastActivityRef.current = Date.now();
      localStorage.setItem("lastActivity", lastActivityRef.current.toString());
    };

    const handleUserActivity = () => updateActivity();

    window.addEventListener("mousemove", handleUserActivity);
    window.addEventListener("keydown", handleUserActivity);
    window.addEventListener("click", handleUserActivity);
    window.addEventListener("scroll", handleUserActivity);

    const checkInactivity = setInterval(() => {
      const storedLastActivity = parseInt(localStorage.getItem("lastActivity") || Date.now().toString(), 10);
      if (Date.now() - storedLastActivity > INACTIVITY_TIMEOUT) {
        logout.mutate(undefined, {
          onSuccess: () => {
            queryClient.setQueryData(getGetMeQueryKey(), { authenticated: false });
            setLocation("/hidden-core-layer");
          },
        });
      }
    }, 30000); // Check every 30 seconds

    return () => {
      window.removeEventListener("mousemove", handleUserActivity);
      window.removeEventListener("keydown", handleUserActivity);
      window.removeEventListener("click", handleUserActivity);
      window.removeEventListener("scroll", handleUserActivity);
      clearInterval(checkInactivity);
    };
  }, [session?.authenticated, logout, setLocation, queryClient]);

  return session;
}
