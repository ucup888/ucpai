import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import NotFound from "@/pages/not-found";
import { StoreLayout, AdminLayout } from "@/components/layout";

// Public pages
import Home from "@/pages/home";
import ProductDetail from "@/pages/product";
import Checkout from "@/pages/checkout";
import About from "@/pages/about";

// Admin pages
import Login from "@/pages/admin/login";
import Dashboard from "@/pages/admin/dashboard";
import AdminProducts from "@/pages/admin/products";
import AdminCategories from "@/pages/admin/categories";
import AdminSettings from "@/pages/admin/settings";
import AdminPayment from "@/pages/admin/payment";
import AdminContact from "@/pages/admin/contact";
import AdminPromo from "@/pages/admin/promo";
import AdminTransactions from "@/pages/admin/transactions";
import AdminFaq from "@/pages/admin/faq";
import AdminAbout from "@/pages/admin/about";
import AdminTheme from "@/pages/admin/theme";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      {/* Public Store */}
      <Route path="/">
        <StoreLayout><Home /></StoreLayout>
      </Route>
      <Route path="/product/:id">
        {params => <StoreLayout><ProductDetail id={params.id} /></StoreLayout>}
      </Route>
      <Route path="/checkout">
        <StoreLayout><Checkout /></StoreLayout>
      </Route>
      <Route path="/about">
        <StoreLayout><About /></StoreLayout>
      </Route>

      {/* Admin Login */}
      <Route path="/hidden-core-layer">
        <Login />
      </Route>

      {/* Admin Workspace */}
      <Route path="/admin">
        <AdminLayout><Dashboard /></AdminLayout>
      </Route>
      <Route path="/admin/products">
        <AdminLayout><AdminProducts /></AdminLayout>
      </Route>
      <Route path="/admin/categories">
        <AdminLayout><AdminCategories /></AdminLayout>
      </Route>
      <Route path="/admin/settings">
        <AdminLayout><AdminSettings /></AdminLayout>
      </Route>
      <Route path="/admin/payment">
        <AdminLayout><AdminPayment /></AdminLayout>
      </Route>
      <Route path="/admin/contact">
        <AdminLayout><AdminContact /></AdminLayout>
      </Route>
      <Route path="/admin/promo">
        <AdminLayout><AdminPromo /></AdminLayout>
      </Route>
      <Route path="/admin/transactions">
        <AdminLayout><AdminTransactions /></AdminLayout>
      </Route>
      <Route path="/admin/faq">
        <AdminLayout><AdminFaq /></AdminLayout>
      </Route>
      <Route path="/admin/about">
        <AdminLayout><AdminAbout /></AdminLayout>
      </Route>
      <Route path="/admin/theme">
        <AdminLayout><AdminTheme /></AdminLayout>
      </Route>

      {/* 404 */}
      <Route>
        <StoreLayout><NotFound /></StoreLayout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
