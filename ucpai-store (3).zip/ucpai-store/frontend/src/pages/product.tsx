import { useGetProduct } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Minus, Plus, ShoppingCart } from "lucide-react";
import { Link } from "wouter";

export default function ProductDetail({ id }: { id: string }) {
  const [, setLocation] = useLocation();
  const productId = parseInt(id, 10);
  const { data: product, isLoading } = useGetProduct(productId, {
    query: { enabled: !isNaN(productId) }
  });
  const [quantity, setQuantity] = useState(1);

  if (isLoading) {
    return (
      <div className="grid md:grid-cols-2 gap-8">
        <Skeleton className="h-[400px] w-full rounded-xl" />
        <div className="space-y-4">
          <Skeleton className="h-10 w-3/4" />
          <Skeleton className="h-6 w-1/4" />
          <Skeleton className="h-24 w-full" />
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Product not found</h2>
        <Button asChild>
          <Link href="/">Back to Store</Link>
        </Button>
      </div>
    );
  }

  const handleCheckout = () => {
    sessionStorage.setItem("checkout_item", JSON.stringify({
      productId: product.id,
      productName: product.name,
      productPrice: product.price,
      quantity,
      totalPrice: product.price * quantity
    }));
    setLocation("/checkout");
  };

  return (
    <div className="max-w-5xl mx-auto">
      <Link href="/" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary mb-6 transition-colors">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Store
      </Link>
      
      <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
        {/* Product Image */}
        <div className="relative aspect-square md:aspect-[4/3] lg:aspect-square bg-muted rounded-xl overflow-hidden shadow-sm">
          {product.image ? (
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground bg-secondary/10">
              No Image
            </div>
          )}
          {product.badge && (
            <Badge className="absolute top-4 right-4 shadow-md text-sm px-3 py-1">
              {product.badge}
            </Badge>
          )}
        </div>

        {/* Product Info */}
        <div className="flex flex-col">
          <div className="mb-2">
            {product.category && (
              <span className="text-sm font-semibold text-primary uppercase tracking-wider">{product.category}</span>
            )}
          </div>
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-4">
            {product.name}
          </h1>
          <p className="text-3xl font-bold text-primary mb-6">
            Rp {product.price.toLocaleString("id-ID")}
          </p>
          
          <div className="prose prose-sm dark:prose-invert max-w-none mb-8 text-muted-foreground">
            {product.description ? (
               <div dangerouslySetInnerHTML={{ __html: product.description.replace(/\n/g, "<br/>") }} />
            ) : (
              <p>No description available.</p>
            )}
          </div>

          <Card className="mt-auto border-primary/20 bg-card/50 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <span className="font-medium text-lg">Quantity</span>
                <div className="flex items-center gap-4 bg-muted p-1 rounded-lg">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 rounded-md"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="w-8 text-center font-semibold text-lg">{quantity}</span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 rounded-md"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex items-center justify-between mb-6 pb-6 border-b">
                <span className="font-semibold text-lg">Total</span>
                <span className="text-2xl font-bold text-primary">
                  Rp {(product.price * quantity).toLocaleString("id-ID")}
                </span>
              </div>

              <Button 
                size="lg" 
                className="w-full text-lg h-14"
                onClick={handleCheckout}
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                Buy Now
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
