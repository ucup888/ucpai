import { useState, useEffect } from "react";
import { useGetContact, useUpdateContact, getGetContactQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Save } from "lucide-react";

export default function AdminContact() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: contact, isLoading } = useGetContact();
  const updateContact = useUpdateContact();

  const [form, setForm] = useState({
    whatsapp: "",
    telegram: ""
  });

  useEffect(() => {
    if (contact) {
      setForm({
        whatsapp: contact.whatsapp || "",
        telegram: contact.telegram || ""
      });
    }
  }, [contact]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold tracking-tight">Contact Information</h1>
        <Skeleton className="h-48 w-full max-w-2xl" />
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateContact.mutate({ data: form }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetContactQueryKey() });
        toast({ title: "Contact info saved successfully" });
      }
    });
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-3xl font-bold tracking-tight">Contact Information</h1>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle>Customer Support</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>WhatsApp Number</Label>
              <Input 
                value={form.whatsapp} 
                onChange={e => setForm({...form, whatsapp: e.target.value})} 
                placeholder="628123456789" 
              />
              <p className="text-xs text-muted-foreground">Used for checkout redirection and customer support.</p>
            </div>
            
            <div className="space-y-2">
              <Label>Telegram Username</Label>
              <Input 
                value={form.telegram} 
                onChange={e => setForm({...form, telegram: e.target.value})} 
                placeholder="@yourusername" 
              />
            </div>
          </CardContent>
        </Card>

        <Button type="submit" disabled={updateContact.isPending} className="w-full md:w-auto">
          <Save className="w-4 h-4 mr-2" />
          {updateContact.isPending ? "Saving..." : "Save Settings"}
        </Button>
      </form>
    </div>
  );
}
