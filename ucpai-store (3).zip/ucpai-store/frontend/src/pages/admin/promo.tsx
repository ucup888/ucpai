import { useState, useEffect } from "react";
import { useGetPromo, useUpdatePromo, getGetPromoQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Save } from "lucide-react";

export default function AdminPromo() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: promo, isLoading } = useGetPromo();
  const updatePromo = useUpdatePromo();

  const [form, setForm] = useState({
    enabled: false,
    text: ""
  });

  useEffect(() => {
    if (promo) {
      setForm({
        enabled: promo.enabled || false,
        text: promo.text || ""
      });
    }
  }, [promo]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold tracking-tight">Promo Banner</h1>
        <Skeleton className="h-48 w-full max-w-2xl" />
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updatePromo.mutate({ data: form }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetPromoQueryKey() });
        toast({ title: "Promo settings saved successfully" });
      }
    });
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-3xl font-bold tracking-tight">Promo Banner</h1>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle>Top Banner Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between space-x-2">
              <Label htmlFor="promo-enabled" className="flex flex-col space-y-1">
                <span>Enable Promo Banner</span>
                <span className="font-normal text-sm text-muted-foreground">Show a top banner across the store.</span>
              </Label>
              <Switch 
                id="promo-enabled" 
                checked={form.enabled} 
                onCheckedChange={v => setForm({...form, enabled: v})} 
              />
            </div>
            
            <div className="space-y-2">
              <Label>Promo Text</Label>
              <Input 
                value={form.text} 
                onChange={e => setForm({...form, text: e.target.value})} 
                placeholder="Get 50% off all products today!" 
              />
            </div>
          </CardContent>
        </Card>

        <Button type="submit" disabled={updatePromo.isPending} className="w-full md:w-auto">
          <Save className="w-4 h-4 mr-2" />
          {updatePromo.isPending ? "Saving..." : "Save Settings"}
        </Button>
      </form>
    </div>
  );
}
