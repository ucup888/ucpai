import { useState, useEffect } from "react";
import { useGetSettings, useUpdateSettings, getGetSettingsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Save } from "lucide-react";

export default function AdminSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: settings, isLoading } = useGetSettings();
  const updateSettings = useUpdateSettings();

  const [form, setForm] = useState({
    siteName: "",
    siteTitle: "",
    logo: "",
    bannerImage: "",
    heroTitle: "",
    heroSubtitle: "",
    statProducts: "",
    statMembers: "",
    statYears: ""
  });

  useEffect(() => {
    if (settings) {
      setForm({
        siteName: settings.siteName || "",
        siteTitle: settings.siteTitle || "",
        logo: settings.logo || "",
        bannerImage: settings.bannerImage || "",
        heroTitle: settings.heroTitle || "",
        heroSubtitle: settings.heroSubtitle || "",
        statProducts: settings.statProducts || "",
        statMembers: settings.statMembers || "",
        statYears: settings.statYears || ""
      });
    }
  }, [settings]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold tracking-tight">General Settings</h1>
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings.mutate({ data: form }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetSettingsQueryKey() });
        toast({ title: "Settings saved successfully" });
      }
    });
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <h1 className="text-3xl font-bold tracking-tight">General Settings</h1>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle>Site Identity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Site Name</Label>
                <Input value={form.siteName} onChange={e => setForm({...form, siteName: e.target.value})} required />
              </div>
              <div className="space-y-2">
                <Label>Browser Tab Title</Label>
                <Input value={form.siteTitle} onChange={e => setForm({...form, siteTitle: e.target.value})} required />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Logo URL</Label>
              <Input value={form.logo} onChange={e => setForm({...form, logo: e.target.value})} placeholder="https://..." />
              {form.logo && (
                <div className="mt-2 p-2 bg-muted rounded-md inline-block">
                  <img src={form.logo} alt="Logo Preview" className="h-10 w-10 object-contain" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle>Homepage Hero & Banner</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Banner Image URL</Label>
              <Input value={form.bannerImage} onChange={e => setForm({...form, bannerImage: e.target.value})} placeholder="https://..." />
              {form.bannerImage && (
                <div className="mt-2 h-32 w-full max-w-md rounded-md border overflow-hidden">
                  <img src={form.bannerImage} alt="Banner Preview" className="w-full h-full object-cover" />
                </div>
              )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Hero Title</Label>
                <Input value={form.heroTitle} onChange={e => setForm({...form, heroTitle: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Hero Subtitle</Label>
                <Input value={form.heroSubtitle} onChange={e => setForm({...form, heroSubtitle: e.target.value})} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle>Stats Row Labels</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Products Stat (e.g. 1K+)</Label>
                <Input value={form.statProducts} onChange={e => setForm({...form, statProducts: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Members Stat (e.g. 50K+)</Label>
                <Input value={form.statMembers} onChange={e => setForm({...form, statMembers: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Years Stat (e.g. 5+)</Label>
                <Input value={form.statYears} onChange={e => setForm({...form, statYears: e.target.value})} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Button type="submit" disabled={updateSettings.isPending} className="w-full md:w-auto">
          <Save className="w-4 h-4 mr-2" />
          {updateSettings.isPending ? "Saving..." : "Save Settings"}
        </Button>
      </form>
    </div>
  );
}
