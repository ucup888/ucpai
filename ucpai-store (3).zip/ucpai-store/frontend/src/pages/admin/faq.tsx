import { useState } from "react";
import { 
  useGetFaqs, 
  useCreateFaq, 
  useUpdateFaq, 
  useDeleteFaq, 
  getGetFaqsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Edit, Plus, Trash2 } from "lucide-react";
import type { FaqItem } from "@workspace/api-client-react";

export default function AdminFaq() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: faqs, isLoading } = useGetFaqs();
  const createFaq = useCreateFaq();
  const updateFaq = useUpdateFaq();
  const deleteFaq = useDeleteFaq();

  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  
  const [form, setForm] = useState({
    question: "",
    answer: "",
    order: "0"
  });

  const resetForm = () => {
    setForm({ question: "", answer: "", order: "0" });
    setEditingId(null);
  };

  const handleEdit = (faq: FaqItem) => {
    setForm({
      question: faq.question,
      answer: faq.answer,
      order: faq.order.toString()
    });
    setEditingId(faq.id);
    setIsOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      question: form.question,
      answer: form.answer,
      order: parseInt(form.order, 10)
    };

    if (editingId) {
      updateFaq.mutate({ id: editingId, data: payload }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetFaqsQueryKey() });
          toast({ title: "FAQ updated" });
          setIsOpen(false);
          resetForm();
        }
      });
    } else {
      createFaq.mutate({ data: payload }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetFaqsQueryKey() });
          toast({ title: "FAQ created" });
          setIsOpen(false);
          resetForm();
        }
      });
    }
  };

  const handleDelete = (id: number) => {
    if (!confirm("Are you sure you want to delete this FAQ?")) return;
    deleteFaq.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetFaqsQueryKey() });
        toast({ title: "FAQ deleted" });
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">FAQ Manager</h1>
        <Dialog open={isOpen} onOpenChange={(open) => { setIsOpen(open); if(!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4"/> Add FAQ</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingId ? "Edit FAQ" : "New FAQ"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Question</Label>
                <Input value={form.question} onChange={e => setForm({...form, question: e.target.value})} required />
              </div>
              <div className="space-y-2">
                <Label>Answer</Label>
                <Textarea value={form.answer} onChange={e => setForm({...form, answer: e.target.value})} rows={4} required />
              </div>
              <div className="space-y-2">
                <Label>Sort Order</Label>
                <Input type="number" value={form.order} onChange={e => setForm({...form, order: e.target.value})} required />
              </div>
              <div className="flex justify-end pt-4">
                <Button type="submit" disabled={createFaq.isPending || updateFaq.isPending}>
                  {editingId ? "Save Changes" : "Create"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="border rounded-lg bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16">Order</TableHead>
              <TableHead>Question</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={3} className="text-center">Loading...</TableCell></TableRow>
            ) : faqs?.length === 0 ? (
              <TableRow><TableCell colSpan={3} className="text-center">No FAQs found.</TableCell></TableRow>
            ) : (
              faqs?.sort((a,b) => a.order - b.order).map(faq => (
                <TableRow key={faq.id}>
                  <TableCell className="font-medium text-muted-foreground">{faq.order}</TableCell>
                  <TableCell className="font-medium">{faq.question}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(faq)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleDelete(faq.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
