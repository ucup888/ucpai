import { useState, useEffect } from "react";
import { useGetPayment, useUpdatePayment, getGetPaymentQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Save } from "lucide-react";

export default function AdminPayment() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: payment, isLoading } = useGetPayment();
  const updatePayment = useUpdatePayment();

  const [form, setForm] = useState({
    accountNumber: "",
    qrisImage: "",
    instructions: ""
  });

  useEffect(() => {
    if (payment) {
      setForm({
        accountNumber: payment.accountNumber || "",
        qrisImage: payment.qrisImage || "",
        instructions: payment.instructions || ""
      });
    }
  }, [payment]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold tracking-tight">Payment Configuration</h1>
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updatePayment.mutate({ data: form }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetPaymentQueryKey() });
        toast({ title: "Payment settings saved successfully" });
      }
    });
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <h1 className="text-3xl font-bold tracking-tight">Payment Configuration</h1>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle>Bank & QRIS Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Bank Account Number</Label>
              <Input value={form.accountNumber} onChange={e => setForm({...form, accountNumber: e.target.value})} />
            </div>
            
            <div className="space-y-2">
              <Label>QRIS Image URL</Label>
              <Input value={form.qrisImage} onChange={e => setForm({...form, qrisImage: e.target.value})} placeholder="https://..." />
              {form.qrisImage && (
                <div className="mt-2 h-48 w-48 rounded-xl border bg-white p-2">
                  <img src={form.qrisImage} alt="QRIS Preview" className="w-full h-full object-contain" />
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Payment Instructions (HTML/Text)</Label>
              <Textarea 
                value={form.instructions} 
                onChange={e => setForm({...form, instructions: e.target.value})} 
                rows={6} 
                placeholder="Please transfer to..."
              />
            </div>
          </CardContent>
        </Card>

        <Button type="submit" disabled={updatePayment.isPending} className="w-full md:w-auto">
          <Save className="w-4 h-4 mr-2" />
          {updatePayment.isPending ? "Saving..." : "Save Settings"}
        </Button>
      </form>
    </div>
  );
}
