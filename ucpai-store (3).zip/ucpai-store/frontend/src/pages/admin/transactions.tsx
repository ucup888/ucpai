import { useGetTransactions, useUpdateTransaction, useDeleteTransaction, getGetTransactionsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Trash2 } from "lucide-react";
import { format } from "date-fns";

const STATUS_COLORS: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  pending: "outline",
  paid: "secondary",
  done: "default",
  cancelled: "destructive"
};

export default function AdminTransactions() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: transactions, isLoading } = useGetTransactions();
  const updateTransaction = useUpdateTransaction();
  const deleteTransaction = useDeleteTransaction();

  const handleStatusChange = (id: number, status: string) => {
    updateTransaction.mutate({ id, data: { status } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetTransactionsQueryKey() });
        toast({ title: "Status updated" });
      }
    });
  };

  const handleDelete = (id: number) => {
    if (!confirm("Are you sure you want to delete this transaction?")) return;
    deleteTransaction.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetTransactionsQueryKey() });
        toast({ title: "Transaction deleted" });
      }
    });
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">Transactions</h1>

      <div className="border rounded-lg bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Product</TableHead>
              <TableHead>Total</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={6} className="text-center">Loading...</TableCell></TableRow>
            ) : transactions?.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center">No transactions found.</TableCell></TableRow>
            ) : (
              transactions?.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(t => (
                <TableRow key={t.id}>
                  <TableCell className="whitespace-nowrap">
                    {format(new Date(t.createdAt), "dd MMM yyyy, HH:mm")}
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{t.customerName}</div>
                    <div className="text-xs text-muted-foreground">{t.customerPhone}</div>
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{t.productName}</div>
                    <div className="text-xs text-muted-foreground">Qty: {t.quantity}</div>
                  </TableCell>
                  <TableCell className="font-bold">Rp {t.totalPrice.toLocaleString("id-ID")}</TableCell>
                  <TableCell>
                    <Select value={t.status} onValueChange={(v) => handleStatusChange(t.id, v)}>
                      <SelectTrigger className="w-[130px] h-8">
                        <SelectValue>
                          <Badge variant={STATUS_COLORS[t.status] || "outline"}>{t.status}</Badge>
                        </SelectValue>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending"><Badge variant="outline">pending</Badge></SelectItem>
                        <SelectItem value="paid"><Badge variant="secondary">paid</Badge></SelectItem>
                        <SelectItem value="done"><Badge variant="default">done</Badge></SelectItem>
                        <SelectItem value="cancelled"><Badge variant="destructive">cancelled</Badge></SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleDelete(t.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
