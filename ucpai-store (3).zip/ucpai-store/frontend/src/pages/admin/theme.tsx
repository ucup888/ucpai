import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Moon, Sun, Monitor } from "lucide-react";

export default function AdminTheme() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-3xl font-bold tracking-tight">Theme Preferences</h1>
      
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle>Appearance</CardTitle>
          <CardDescription>Select the theme for your store and admin panel.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex gap-4">
            <Button 
              variant={theme === "light" ? "default" : "outline"} 
              className="flex-1 h-24 flex-col gap-2"
              onClick={() => setTheme("light")}
            >
              <Sun className="h-6 w-6" />
              Light
            </Button>
            <Button 
              variant={theme === "dark" ? "default" : "outline"} 
              className="flex-1 h-24 flex-col gap-2"
              onClick={() => setTheme("dark")}
            >
              <Moon className="h-6 w-6" />
              Dark
            </Button>
            <Button 
              variant={theme === "system" ? "default" : "outline"} 
              className="flex-1 h-24 flex-col gap-2"
              onClick={() => setTheme("system")}
            >
              <Monitor className="h-6 w-6" />
              System
            </Button>
          </div>
          
          <div className="rounded-lg border p-4 bg-muted/50">
            <h3 className="font-medium mb-2 flex items-center gap-2">
              <span className="h-3 w-3 rounded-full bg-primary inline-block" /> Primary Color
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              Your primary brand color is an energetic blue (230 80% 55%) matched with a bright yellow secondary accent (45 95% 55%). This is controlled in the global CSS.
            </p>
            <div className="flex gap-2">
              <div className="h-10 w-10 rounded-md bg-primary border" />
              <div className="h-10 w-10 rounded-md bg-secondary border" />
              <div className="h-10 w-10 rounded-md bg-destructive border" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
