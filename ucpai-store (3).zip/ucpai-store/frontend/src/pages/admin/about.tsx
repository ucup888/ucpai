import { useState, useEffect } from "react";
import { useGetAbout, useUpdateAbout, getGetAboutQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Save } from "lucide-react";

export default function AdminAbout() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: about, isLoading } = useGetAbout();
  const updateAbout = useUpdateAbout();

  const [content, setContent] = useState("");

  useEffect(() => {
    if (about) {
      setContent(about.content || "");
    }
  }, [about]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold tracking-tight">About Page Content</h1>
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateAbout.mutate({ data: { content } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetAboutQueryKey() });
        toast({ title: "About page saved successfully" });
      }
    });
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <h1 className="text-3xl font-bold tracking-tight">About Page Content</h1>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle>Content (HTML/Text)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Main Content</Label>
              <Textarea 
                value={content} 
                onChange={e => setContent(e.target.value)} 
                rows={15} 
                className="font-mono text-sm"
                placeholder="<p>Welcome to our store...</p>"
              />
              <p className="text-xs text-muted-foreground">Supports basic HTML tags for formatting.</p>
            </div>
          </CardContent>
        </Card>

        <Button type="submit" disabled={updateAbout.isPending} className="w-full md:w-auto">
          <Save className="w-4 h-4 mr-2" />
          {updateAbout.isPending ? "Saving..." : "Save Changes"}
        </Button>
      </form>
    </div>
  );
}
