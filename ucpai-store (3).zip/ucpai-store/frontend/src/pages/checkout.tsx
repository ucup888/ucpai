import { useState } from "react";
import { useLocation } from "wouter";
import { useGetPayment, useGetContact, useCreateTransaction } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, MessageCircle } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { data: payment } = useGetPayment();
  const { data: contact } = useGetContact();
  const createTransaction = useCreateTransaction();

  // Try to parse checkout item from session storage
  let initialItem = null;
  try {
    const stored = sessionStorage.getItem("checkout_item");
    if (stored) initialItem = JSON.parse(stored);
  } catch (e) {
    // ignore
  }

  const [item] = useState<{
    productId?: number;
    productName: string;
    productPrice: number;
    quantity: number;
    totalPrice: number;
  } | null>(initialItem);

  const [form, setForm] = useState({
    customerName: "",
    customerPhone: "",
    notes: ""
  });

  if (!item) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">No items to checkout</h2>
        <Button asChild>
          <Link href="/">Back to Store</Link>
        </Button>
      </div>
    );
  }

  const handleCheckout = () => {
    if (!form.customerName.trim()) {
      toast({
        title: "Name is required",
        variant: "destructive"
      });
      return;
    }
    
    // Create transaction record
    createTransaction.mutate({
      data: {
        customerName: form.customerName,
        customerPhone: form.customerPhone || undefined,
        productId: item.productId,
        productName: item.productName,
        productPrice: item.productPrice,
        quantity: item.quantity,
        totalPrice: item.totalPrice,
        notes: form.notes || undefined
      }
    }, {
      onSuccess: () => {
        // Build whatsapp message
        if (contact?.whatsapp) {
          const text = `Halo, saya ingin memesan ${item.productName} x${item.quantity} seharga Rp${item.totalPrice.toLocaleString("id-ID")}. Nama: ${form.customerName}`;
          const encodedText = encodeURIComponent(text);
          // Remove leading 0 and add 62 if needed for Indonesian numbers, though usually wa.me handles well if clean
          let waNumber = contact.whatsapp.replace(/\D/g, "");
          if (waNumber.startsWith("0")) {
            waNumber = "62" + waNumber.substring(1);
          }
          window.open(`https://wa.me/${waNumber}?text=${encodedText}`, "_blank");
        }
        
        sessionStorage.removeItem("checkout_item");
        toast({
          title: "Order Created",
          description: "Redirecting to WhatsApp...",
        });
        setLocation("/");
      },
      onError: () => {
        toast({
          title: "Failed to create order",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
      <div>
        <Link href={`/product/${item.productId}`} className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary mb-6 transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Product
        </Link>

        <h1 className="text-3xl font-extrabold mb-6">Checkout</h1>

        <Card className="mb-6 border-primary/20">
          <CardHeader className="bg-muted/50 pb-4">
            <CardTitle>Order Summary</CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="flex justify-between mb-2">
              <span className="font-medium">{item.productName} (x{item.quantity})</span>
              <span>Rp {item.totalPrice.toLocaleString("id-ID")}</span>
            </div>
            <Separator className="my-4" />
            <div className="flex justify-between font-bold text-lg text-primary">
              <span>Total</span>
              <span>Rp {item.totalPrice.toLocaleString("id-ID")}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="bg-muted/50 pb-4">
            <CardTitle>Your Details</CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input 
                id="name" 
                placeholder="John Doe" 
                value={form.customerName}
                onChange={e => setForm({...form, customerName: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input 
                id="phone" 
                placeholder="08123456789" 
                value={form.customerPhone}
                onChange={e => setForm({...form, customerPhone: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea 
                id="notes" 
                placeholder="Any special instructions..." 
                value={form.notes}
                onChange={e => setForm({...form, notes: e.target.value})}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6 md:mt-[3.75rem]">
        <Card className="border-secondary overflow-hidden">
          <CardHeader className="bg-secondary/10 pb-4">
            <CardTitle className="text-secondary-foreground">Payment Instructions</CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-4">
            {payment?.instructions && (
              <div className="prose prose-sm dark:prose-invert">
                <div dangerouslySetInnerHTML={{ __html: payment.instructions.replace(/\n/g, "<br/>") }} />
              </div>
            )}
            
            {payment?.accountNumber && (
              <div className="bg-muted p-3 rounded-lg border text-center font-mono text-lg font-bold tracking-wider">
                {payment.accountNumber}
              </div>
            )}

            {payment?.qrisImage && (
              <div className="mt-4 flex flex-col items-center">
                <p className="text-sm font-semibold mb-2">Scan QRIS</p>
                <img src={payment.qrisImage} alt="QRIS Payment" className="w-48 h-48 rounded-xl object-contain bg-white p-2 border shadow-sm" />
              </div>
            )}
          </CardContent>
        </Card>

        <Button 
          size="lg" 
          className="w-full h-14 text-lg bg-[#25D366] hover:bg-[#128C7E] text-white"
          onClick={handleCheckout}
          disabled={createTransaction.isPending}
        >
          <MessageCircle className="mr-2 h-6 w-6" />
          Order via WhatsApp
        </Button>
        <p className="text-center text-xs text-muted-foreground">
          You will be redirected to WhatsApp to complete your order.
        </p>
      </div>
    </div>
  );
}
