import { useGetSettings, useGetProducts, useGetCategories } from "@workspace/api-client-react";
import { Link } from "wouter";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { data: settings, isLoading: loadingSettings } = useGetSettings();
  const { data: categories, isLoading: loadingCategories } = useGetCategories();
  
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(undefined);
  
  const { data: products, isLoading: loadingProducts } = useGetProducts({ 
    category: selectedCategory === "all" ? undefined : selectedCategory 
  });

  return (
    <div className="flex flex-col gap-8">
      {/* Hero Banner */}
      <div className="w-full">
        {loadingSettings ? (
          <Skeleton className="w-full h-48 md:h-64 lg:h-80 rounded-xl" />
        ) : settings?.bannerImage ? (
          <img 
            src={settings.bannerImage} 
            alt="Store Banner" 
            className="w-full h-48 md:h-64 lg:h-80 object-cover rounded-xl"
          />
        ) : (
          <div className="w-full h-48 md:h-64 lg:h-80 rounded-xl bg-gradient-to-r from-primary to-secondary" />
        )}
      </div>

      {/* Hero Text */}
      <div className="text-center max-w-2xl mx-auto px-4">
        {loadingSettings ? (
          <div className="space-y-2">
            <Skeleton className="h-8 w-3/4 mx-auto" />
            <Skeleton className="h-4 w-1/2 mx-auto" />
          </div>
        ) : (
          <>
            <h2 className="text-3xl font-extrabold tracking-tight mb-2">
              {settings?.heroTitle || "Welcome to our store"}
            </h2>
            <p className="text-muted-foreground text-lg">
              {settings?.heroSubtitle || "Find the best digital goods right here."}
            </p>
          </>
        )}
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-4 border-y py-6">
        <div className="text-center space-y-1">
          <p className="text-2xl font-black text-primary">{settings?.statProducts || "1K+"}</p>
          <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Products</p>
        </div>
        <div className="text-center border-x space-y-1">
          <p className="text-2xl font-black text-primary">{settings?.statMembers || "50K+"}</p>
          <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Members</p>
        </div>
        <div className="text-center space-y-1">
          <p className="text-2xl font-black text-primary">{settings?.statYears || "5+"}</p>
          <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Years</p>
        </div>
      </div>

      {/* Category Chips */}
      <div>
        <div className="flex items-center gap-2 overflow-x-auto pb-4 no-scrollbar">
          <Button
            variant={!selectedCategory || selectedCategory === "all" ? "default" : "outline"}
            className="rounded-full shrink-0"
            onClick={() => setSelectedCategory("all")}
          >
            Semua
          </Button>
          {loadingCategories ? (
             Array.from({ length: 4 }).map((_, i) => (
               <Skeleton key={i} className="h-9 w-24 rounded-full shrink-0" />
             ))
          ) : (
            categories?.map(cat => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.name ? "default" : "outline"}
                className="rounded-full shrink-0"
                onClick={() => setSelectedCategory(cat.name)}
              >
                {cat.name}
              </Button>
            ))
          )}
        </div>
      </div>

      {/* Product Grid */}
      <div>
        <h3 className="text-xl font-bold mb-4">
          {selectedCategory && selectedCategory !== "all" ? `${selectedCategory} Products` : "All Products"}
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {loadingProducts ? (
            Array.from({ length: 8 }).map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-40 w-full rounded-none" />
                <CardContent className="p-4 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/4" />
                  <Skeleton className="h-8 w-full mt-2" />
                </CardContent>
              </Card>
            ))
          ) : products?.length === 0 ? (
            <div className="col-span-full py-12 text-center text-muted-foreground">
              No products found in this category.
            </div>
          ) : (
            products?.map(product => (
              <Link key={product.id} href={`/product/${product.id}`}>
                <Card className="overflow-hidden hover-elevate cursor-pointer group h-full flex flex-col transition-all duration-300 border-border/50 hover:border-primary/30">
                  <div className="relative aspect-[4/3] bg-muted overflow-hidden">
                    {product.image ? (
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground font-medium bg-secondary/10">
                        No Image
                      </div>
                    )}
                    {product.badge && (
                      <Badge className="absolute top-2 right-2 shadow-sm font-semibold tracking-wide">
                        {product.badge}
                      </Badge>
                    )}
                  </div>
                  <CardContent className="p-4 flex flex-col flex-1 gap-1">
                    <h4 className="font-semibold line-clamp-2 text-sm md:text-base leading-snug group-hover:text-primary transition-colors">
                      {product.name}
                    </h4>
                    <p className="text-primary font-bold mt-auto pt-2">
                      Rp {product.price.toLocaleString("id-ID")}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
