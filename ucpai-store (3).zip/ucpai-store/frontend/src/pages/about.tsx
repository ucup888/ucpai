import { useGetAbout, useGetFaqs } from "@workspace/api-client-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function About() {
  const { data: about, isLoading: loadingAbout } = useGetAbout();
  const { data: faqs, isLoading: loadingFaqs } = useGetFaqs();

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <section>
        <h1 className="text-4xl font-extrabold mb-8 tracking-tight">About Us</h1>
        {loadingAbout ? (
          <div className="space-y-4">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-[90%]" />
            <Skeleton className="h-4 w-[95%]" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-[80%]" />
          </div>
        ) : (
          <div className="prose prose-lg dark:prose-invert max-w-none text-muted-foreground leading-relaxed">
            {about?.content ? (
              <div dangerouslySetInnerHTML={{ __html: about.content.replace(/\n/g, "<br/>") }} />
            ) : (
              <p>Welcome to our store. We provide the best digital goods.</p>
            )}
          </div>
        )}
      </section>

      <section>
        <h2 className="text-3xl font-bold mb-8 tracking-tight">Frequently Asked Questions</h2>
        {loadingFaqs ? (
          <div className="space-y-4">
            <Skeleton className="h-12 w-full rounded-md" />
            <Skeleton className="h-12 w-full rounded-md" />
            <Skeleton className="h-12 w-full rounded-md" />
          </div>
        ) : faqs && faqs.length > 0 ? (
          <Card className="border-primary/20 shadow-sm bg-card/50">
            <CardContent className="p-6">
              <Accordion type="single" collapsible className="w-full">
                {faqs.sort((a, b) => a.order - b.order).map((faq) => (
                  <AccordionItem key={faq.id} value={`faq-${faq.id}`}>
                    <AccordionTrigger className="text-left font-semibold text-lg hover:text-primary transition-colors">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground text-base leading-relaxed">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        ) : (
          <p className="text-muted-foreground">No FAQs available yet.</p>
        )}
      </section>
    </div>
  );
}
