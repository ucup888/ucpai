import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import productsRouter from "./products";
import categoriesRouter from "./categories";
import settingsRouter from "./settings";
import transactionsRouter from "./transactions";
import faqRouter from "./faq";
import statsRouter from "./stats";
import uploadRouter from "./upload";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/products", productsRouter);
router.use("/categories", categoriesRouter);
router.use(settingsRouter);
router.use("/transactions", transactionsRouter);
router.use(faqRouter);
router.use("/stats", statsRouter);
router.use("/upload", uploadRouter);

export default router;
