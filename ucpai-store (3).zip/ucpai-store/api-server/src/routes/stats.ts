import { Router } from "express";
import { db } from "@workspace/db";
import { productsTable, categoriesTable, transactionsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const router = Router();

router.get("/", async (_req, res) => {
  const [productCount] = await db.select({ count: sql<number>`count(*)::int` }).from(productsTable);
  const [categoryCount] = await db.select({ count: sql<number>`count(*)::int` }).from(categoriesTable);
  const [transactionCount] = await db.select({ count: sql<number>`count(*)::int` }).from(transactionsTable);
  const [pendingCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(transactionsTable)
    .where(eq(transactionsTable.status, "pending"));
  const [revenue] = await db
    .select({ total: sql<number>`COALESCE(SUM(total_price::numeric), 0)::float` })
    .from(transactionsTable)
    .where(eq(transactionsTable.status, "done"));

  res.json({
    totalProducts: productCount?.count ?? 0,
    totalCategories: categoryCount?.count ?? 0,
    totalTransactions: transactionCount?.count ?? 0,
    pendingTransactions: pendingCount?.count ?? 0,
    totalRevenue: revenue?.total ?? 0,
  });
});

export default router;
