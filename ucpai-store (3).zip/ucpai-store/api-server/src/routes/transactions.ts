import { Router } from "express";
import { db } from "@workspace/db";
import { transactionsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "../lib/logger";

const router = Router();

function serialize(t: typeof transactionsTable.$inferSelect) {
  return {
    ...t,
    productPrice: parseFloat(t.productPrice),
    totalPrice: parseFloat(t.totalPrice),
    createdAt: t.createdAt.toISOString(),
    updatedAt: t.updatedAt.toISOString(),
  };
}

router.get("/", async (_req, res) => {
  const rows = await db.select().from(transactionsTable).orderBy(transactionsTable.createdAt);
  res.json(rows.map(serialize));
});

router.post("/", async (req, res) => {
  const { customerName, customerPhone, productId, productName, productPrice, quantity, totalPrice, notes } = req.body;
  if (!customerName || !productName || productPrice == null || !quantity || totalPrice == null) {
    res.status(400).json({ error: "Missing required fields" });
    return;
  }
  const [row] = await db
    .insert(transactionsTable)
    .values({
      customerName,
      customerPhone,
      productId,
      productName,
      productPrice: String(productPrice),
      quantity,
      totalPrice: String(totalPrice),
      notes,
      status: "pending",
    })
    .returning();
  logger.info({ id: row.id }, "Transaction created");
  res.status(201).json(serialize(row));
});

router.patch("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const updates: Record<string, unknown> = {};
  if (req.body.status != null) updates.status = req.body.status;
  if ("notes" in req.body) updates.notes = req.body.notes;
  const [row] = await db
    .update(transactionsTable)
    .set(updates)
    .where(eq(transactionsTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  res.json(serialize(row));
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(transactionsTable).where(eq(transactionsTable.id, id));
  res.json({ success: true });
});

export default router;
