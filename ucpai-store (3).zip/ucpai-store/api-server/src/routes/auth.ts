import { Router } from "express";
import { db } from "@workspace/db";
import { adminSessionTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import crypto from "crypto";
import { logger } from "../lib/logger";

const router = Router();

const ADMIN_EMAIL = "tabsamaran07@gmail.com";
const ADMIN_PASSWORD = "U753951cup##";
const SESSION_DURATION_MS = 15 * 60 * 1000; // 15 minutes

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  if (email !== ADMIN_EMAIL || password !== ADMIN_PASSWORD) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  const token = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DURATION_MS);
  await db.insert(adminSessionTable).values({ token, email, expiresAt });
  res.cookie("admin_token", token, {
    httpOnly: true,
    sameSite: "lax",
    maxAge: SESSION_DURATION_MS,
  });
  logger.info({ email }, "Admin logged in");
  res.json({ success: true, token });
});

router.post("/logout", async (req, res) => {
  const token = req.cookies?.admin_token;
  if (token) {
    await db.delete(adminSessionTable).where(eq(adminSessionTable.token, token));
  }
  res.clearCookie("admin_token");
  res.json({ success: true });
});

router.get("/me", async (req, res) => {
  const token = req.cookies?.admin_token;
  if (!token) {
    res.json({ authenticated: false, email: null });
    return;
  }
  const [session] = await db
    .select()
    .from(adminSessionTable)
    .where(eq(adminSessionTable.token, token))
    .limit(1);
  if (!session || session.expiresAt < new Date()) {
    if (session) {
      await db.delete(adminSessionTable).where(eq(adminSessionTable.token, token));
    }
    res.clearCookie("admin_token");
    res.json({ authenticated: false, email: null });
    return;
  }
  res.json({ authenticated: true, email: session.email });
});

export default router;
