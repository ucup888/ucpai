import { Router } from "express";
import { db } from "@workspace/db";
import { faqTable, aboutTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";

const router = Router();

router.get("/faq", async (_req, res) => {
  const rows = await db.select().from(faqTable).orderBy(asc(faqTable.order));
  res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/faq", async (req, res) => {
  const { question, answer, order } = req.body;
  if (!question || !answer) {
    res.status(400).json({ error: "question and answer are required" });
    return;
  }
  const [row] = await db.insert(faqTable).values({ question, answer, order: order ?? 0 }).returning();
  res.status(201).json({ ...row, createdAt: row.createdAt.toISOString() });
});

router.patch("/faq/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const { question, answer, order } = req.body;
  const updates: Record<string, unknown> = {};
  if (question != null) updates.question = question;
  if (answer != null) updates.answer = answer;
  if (order != null) updates.order = order;
  const [row] = await db.update(faqTable).set(updates).where(eq(faqTable.id, id)).returning();
  if (!row) {
    res.status(404).json({ error: "FAQ not found" });
    return;
  }
  res.json({ ...row, createdAt: row.createdAt.toISOString() });
});

router.delete("/faq/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(faqTable).where(eq(faqTable.id, id));
  res.json({ success: true });
});

async function ensureAbout() {
  const rows = await db.select().from(aboutTable).limit(1);
  if (rows.length === 0) {
    const [row] = await db.insert(aboutTable).values({ content: "Selamat datang di UCPAI Store! Kami adalah toko digital terpercaya yang menyediakan berbagai produk digital berkualitas tinggi dengan harga terjangkau." }).returning();
    return row;
  }
  return rows[0];
}

router.get("/about", async (_req, res) => {
  const row = await ensureAbout();
  res.json({ id: row.id, content: row.content });
});

router.patch("/about", async (req, res) => {
  const row = await ensureAbout();
  const { content } = req.body;
  if (!content) {
    res.status(400).json({ error: "content is required" });
    return;
  }
  const [updated] = await db.update(aboutTable).set({ content }).where(eq(aboutTable.id, row.id)).returning();
  res.json({ id: updated.id, content: updated.content });
});

export default router;
