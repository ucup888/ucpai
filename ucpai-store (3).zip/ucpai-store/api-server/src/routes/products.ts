import { Router } from "express";
import { db } from "@workspace/db";
import { productsTable } from "@workspace/db";
import { eq, ilike, and } from "drizzle-orm";
import { logger } from "../lib/logger";

const router = Router();

router.get("/", async (req, res) => {
  const { category, search } = req.query as { category?: string; search?: string };
  const conditions = [];
  if (category) conditions.push(eq(productsTable.category, category));
  if (search) conditions.push(ilike(productsTable.name, `%${search}%`));
  const rows = conditions.length
    ? await db.select().from(productsTable).where(and(...conditions))
    : await db.select().from(productsTable);
  const products = rows.map((p) => ({
    ...p,
    price: parseFloat(p.price),
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  }));
  res.json(products);
});

router.post("/", async (req, res) => {
  const { name, price, image, category, description, badge } = req.body;
  if (!name || price == null) {
    res.status(400).json({ error: "name and price are required" });
    return;
  }
  const [row] = await db
    .insert(productsTable)
    .values({ name, price: String(price), image, category, description, badge })
    .returning();
  logger.info({ id: row.id }, "Product created");
  res.status(201).json({
    ...row,
    price: parseFloat(row.price),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  });
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const [row] = await db.select().from(productsTable).where(eq(productsTable.id, id)).limit(1);
  if (!row) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.json({
    ...row,
    price: parseFloat(row.price),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  });
});

router.patch("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const updates: Record<string, unknown> = {};
  if (req.body.name != null) updates.name = req.body.name;
  if (req.body.price != null) updates.price = String(req.body.price);
  if ("image" in req.body) updates.image = req.body.image;
  if ("category" in req.body) updates.category = req.body.category;
  if ("description" in req.body) updates.description = req.body.description;
  if ("badge" in req.body) updates.badge = req.body.badge;
  const [row] = await db
    .update(productsTable)
    .set(updates)
    .where(eq(productsTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.json({
    ...row,
    price: parseFloat(row.price),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  });
});

router.delete("/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(productsTable).where(eq(productsTable.id, id));
  res.json({ success: true });
});

export default router;
