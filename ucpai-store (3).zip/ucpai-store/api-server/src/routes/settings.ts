import { Router } from "express";
import { db } from "@workspace/db";
import {
  siteSettingsTable,
  paymentSettingsTable,
  contactInfoTable,
  promoSettingsTable,
} from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

async function ensureSiteSettings() {
  const rows = await db.select().from(siteSettingsTable).limit(1);
  if (rows.length === 0) {
    const [row] = await db.insert(siteSettingsTable).values({}).returning();
    return row;
  }
  return rows[0];
}

router.get("/settings", async (_req, res) => {
  const row = await ensureSiteSettings();
  res.json({
    ...row,
    updatedAt: undefined,
  });
});

router.patch("/settings", async (req, res) => {
  const row = await ensureSiteSettings();
  const updates: Record<string, unknown> = {};
  const fields = ["siteName", "siteTitle", "logo", "bannerImage", "heroTitle", "heroSubtitle", "statProducts", "statMembers", "statYears"] as const;
  for (const f of fields) {
    const dbKey = f.replace(/([A-Z])/g, "_$1").toLowerCase();
    if (f in req.body) updates[dbKey as keyof typeof updates] = req.body[f];
  }
  if (Object.keys(updates).length === 0) {
    res.json({ ...row, updatedAt: undefined });
    return;
  }
  const [updated] = await db.update(siteSettingsTable).set(updates).where(eq(siteSettingsTable.id, row.id)).returning();
  res.json({ ...updated, updatedAt: undefined });
});

async function ensurePayment() {
  const rows = await db.select().from(paymentSettingsTable).limit(1);
  if (rows.length === 0) {
    const [row] = await db.insert(paymentSettingsTable).values({}).returning();
    return row;
  }
  return rows[0];
}

router.get("/payment", async (_req, res) => {
  const row = await ensurePayment();
  res.json({ ...row, updatedAt: undefined });
});

router.patch("/payment", async (req, res) => {
  const row = await ensurePayment();
  const updates: Record<string, unknown> = {};
  if ("accountNumber" in req.body) updates.account_number = req.body.accountNumber;
  if ("qrisImage" in req.body) updates.qris_image = req.body.qrisImage;
  if ("instructions" in req.body) updates.instructions = req.body.instructions;
  if (Object.keys(updates).length === 0) {
    res.json({ ...row, updatedAt: undefined });
    return;
  }
  const [updated] = await db.update(paymentSettingsTable).set(updates).where(eq(paymentSettingsTable.id, row.id)).returning();
  res.json({ ...updated, updatedAt: undefined });
});

async function ensureContact() {
  const rows = await db.select().from(contactInfoTable).limit(1);
  if (rows.length === 0) {
    const [row] = await db.insert(contactInfoTable).values({}).returning();
    return row;
  }
  return rows[0];
}

router.get("/contact", async (_req, res) => {
  const row = await ensureContact();
  res.json({ ...row, updatedAt: undefined });
});

router.patch("/contact", async (req, res) => {
  const row = await ensureContact();
  const updates: Record<string, unknown> = {};
  if ("whatsapp" in req.body) updates.whatsapp = req.body.whatsapp;
  if ("telegram" in req.body) updates.telegram = req.body.telegram;
  if (Object.keys(updates).length === 0) {
    res.json({ ...row, updatedAt: undefined });
    return;
  }
  const [updated] = await db.update(contactInfoTable).set(updates).where(eq(contactInfoTable.id, row.id)).returning();
  res.json({ ...updated, updatedAt: undefined });
});

async function ensurePromo() {
  const rows = await db.select().from(promoSettingsTable).limit(1);
  if (rows.length === 0) {
    const [row] = await db.insert(promoSettingsTable).values({}).returning();
    return row;
  }
  return rows[0];
}

router.get("/promo", async (_req, res) => {
  const row = await ensurePromo();
  res.json({ id: row.id, enabled: row.enabled === "true", text: row.text });
});

router.patch("/promo", async (req, res) => {
  const row = await ensurePromo();
  const updates: Record<string, unknown> = {};
  if ("enabled" in req.body) updates.enabled = req.body.enabled ? "true" : "false";
  if ("text" in req.body) updates.text = req.body.text;
  if (Object.keys(updates).length === 0) {
    res.json({ id: row.id, enabled: row.enabled === "true", text: row.text });
    return;
  }
  const [updated] = await db.update(promoSettingsTable).set(updates).where(eq(promoSettingsTable.id, row.id)).returning();
  res.json({ id: updated.id, enabled: updated.enabled === "true", text: updated.text });
});

export default router;
