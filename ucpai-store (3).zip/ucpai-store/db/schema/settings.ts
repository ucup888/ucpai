import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const siteSettingsTable = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  siteName: text("site_name").notNull().default("UCPAI Store"),
  siteTitle: text("site_title").notNull().default("UCPAI Store - Digital Products"),
  logo: text("logo"),
  bannerImage: text("banner_image"),
  heroTitle: text("hero_title"),
  heroSubtitle: text("hero_subtitle"),
  statProducts: text("stat_products"),
  statMembers: text("stat_members"),
  statYears: text("stat_years"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertSiteSettingsSchema = createInsertSchema(siteSettingsTable).omit({ id: true, updatedAt: true });
export type InsertSiteSettings = z.infer<typeof insertSiteSettingsSchema>;
export type SiteSettings = typeof siteSettingsTable.$inferSelect;

export const paymentSettingsTable = pgTable("payment_settings", {
  id: serial("id").primaryKey(),
  accountNumber: text("account_number"),
  qrisImage: text("qris_image"),
  instructions: text("instructions"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertPaymentSettingsSchema = createInsertSchema(paymentSettingsTable).omit({ id: true, updatedAt: true });
export type InsertPaymentSettings = z.infer<typeof insertPaymentSettingsSchema>;
export type PaymentSettings = typeof paymentSettingsTable.$inferSelect;

export const contactInfoTable = pgTable("contact_info", {
  id: serial("id").primaryKey(),
  whatsapp: text("whatsapp"),
  telegram: text("telegram"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertContactInfoSchema = createInsertSchema(contactInfoTable).omit({ id: true, updatedAt: true });
export type InsertContactInfo = z.infer<typeof insertContactInfoSchema>;
export type ContactInfo = typeof contactInfoTable.$inferSelect;

export const promoSettingsTable = pgTable("promo_settings", {
  id: serial("id").primaryKey(),
  enabled: text("enabled").notNull().default("false"),
  text: text("text"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertPromoSettingsSchema = createInsertSchema(promoSettingsTable).omit({ id: true, updatedAt: true });
export type InsertPromoSettings = z.infer<typeof insertPromoSettingsSchema>;
export type PromoSettings = typeof promoSettingsTable.$inferSelect;
